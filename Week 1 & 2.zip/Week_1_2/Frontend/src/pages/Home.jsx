import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FaUser, FaCalendarAlt } from "react-icons/fa";
import "../Styles/Home.css";

function Home() {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    fetch("http://localhost:3000/posts")
      .then((res) => res.json())
      .then((data) => setPosts(data));
  }, []);

  return (
    <div className="home">
      <h1>Blog Posts</h1>
      {posts.map((post) => (
        <div className="post-card" key={post._id}>
          <h2>
            <Link to={`/posts/${post._id}`}>{post.title}</Link>
          </h2>
          <p>{post.content.slice(0, 120)}...</p>
          <div className="post-meta">
            <span>
              <FaUser /> {post.author?.username || "Anonymous"}
            </span>
            <span>
              <FaCalendarAlt /> {new Date(post.date).toLocaleDateString()}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}

export default Home;
