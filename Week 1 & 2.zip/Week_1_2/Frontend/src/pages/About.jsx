import React from "react";
import { FaPenFancy, FaComments, FaSearch, FaBell } from "react-icons/fa";
import { SiReact, SiNodedotjs, SiMongodb, SiTailwindcss } from "react-icons/si";
import { FaUserCircle } from "react-icons/fa";
import "../Styles/About.css"
function About() {
  return (
    <div className="about">
      <header>
        <h1>About Our Blog</h1>
        <p>
          Welcome to our <strong>Blog Platform</strong> — a vibrant space where
          ideas, stories, and knowledge converge.
        </p>
      </header>

      <section>
        <h2>What You Can Do</h2>
        <ul>
          <li>
            <FaPenFancy /> Create and share posts with the community
          </li>
          <li>
            <FaComments /> Comment on articles and join discussions
          </li>
          <li>
            <FaSearch /> Discover content from diverse authors
          </li>
          <li>
            <FaBell /> Stay updated with the latest topics
          </li>
        </ul>
      </section>

      <section>
        <h2>Built With Modern Tools</h2>
        <p>
          Our platform is powered by the <strong>MERN stack</strong>, ensuring a
          seamless and scalable experience:
        </p>
        <ul>
          <li>
            <SiReact /> <strong>React</strong> – Dynamic and responsive user
            interface
          </li>
          <li>
            <SiNodedotjs /> <strong>Express & Node.js</strong> – Robust backend
            API
          </li>
          <li>
            <SiMongodb /> <strong>MongoDB</strong> – Flexible NoSQL database
          </li>
          <li>
            <SiTailwindcss /> <strong>Tailwind CSS</strong> – Utility-first
            styling
          </li>
        </ul>
      </section>

      <section>
        <h2>Our Goal</h2>
        <p>
          We strive to make blogging simple, engaging, and accessible. Whether
          you're a seasoned writer or a curious reader, our platform empowers
          you to share your voice and connect with a global audience.
        </p>
      </section>

      <section>
        <h2>Meet Our Contributors</h2>
        <ul>
          <li>
            <FaUserCircle /> Jane Doe – Frontend Developer
          </li>
          <li>
            <FaUserCircle /> John Smith – Backend Engineer
          </li>
          <li>
            <FaUserCircle /> Emma Wilson – Content Creator
          </li>
        </ul>
      </section>

      <section>
        <h2>Join Us</h2>
        <p>
          This project is open for contributions! Whether you're a developer,
          designer, or writer, collaborate with us to make this platform even
          better.
        </p>
        <a href="mailto:contact@blogplatform.com">Get Involved</a>
      </section>
    </div>
  );
}

export default About;
