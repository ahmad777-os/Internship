import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import PostPage from "./pages/PostPage";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Signup from "./pages/Signup";   // 👈 add signup page
import Login from "./pages/Login";     // 👈 add login page
import { AuthProvider } from "./context/AuthContext"; // 👈 wrap app with this

function App() {
  return (
    <AuthProvider>
      <Router>
        <Navbar />
        <div className="container">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/posts/:id" element={<PostPage />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/signup" element={<Signup />} />   {/* new */}
            <Route path="/login" element={<Login />} />     {/* new */}
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
